#include <graphics.h>
#include <iostream>

using namespace std;

void credit(void);
void exit(void);
//void game_play();
void newgame(void);
void high_score_hc(void);
void gamerules(void);

void menu(void)
{
    char key;
    setfillstyle(SOLID_FILL,BLACK);
    int x = 45;
    int y=90, t=90;

    while(1)
    {

        readimagefile("img/menu 1.jpg", 0, 0, getmaxx(), getmaxy());
        readimagefile("img/megamind2.jpg", x, y, x+60, y+60);

        key=getch();

        if(y>90 && (key==72 || key=='w'))
        {
            y=y-t;
            bar(x,y+t,x+50,y+50+t);
            x=x-40;

        }
        else if(y<450 && (key==80 || key=='s'))
        {
            y+=t;
            bar(x,y-t,x+50,y+50-t);
            x=x+40;
        }

        else if(y==90 && key==13)
        {
            newgame();
            //game_play();
            setfillstyle(SOLID_FILL, BLACK);
        }
        else if(y==180 && key==13)
        {
            gamerules();
        }
        else if(y==270 && key==13)
        {
            high_score_hc();
        }
    else if(y==360 && key==13)
        {
            credit();
        }
        else if(y==450 && key==13)
        {
            exit();
            break;
        }

    }
}


