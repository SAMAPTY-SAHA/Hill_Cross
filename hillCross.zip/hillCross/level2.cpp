
#include <iostream>
#include <fstream>
#include <string>
#include <graphics.h>
#include <bits/stdc++.h>
using namespace std;

const int MAX_SCORE2 = 4, max_jump2 = 90,s2=0;
char names2[][1000] = {"img/a.jpg", "img/b.jpg", "img/c.jpg", "img/d.jpg"};
int scores2[] = {3, 5, -5, -2};
struct Fruit2{
    int x2, y2, w2, h2;
    int score2;
    int index2;
    //for chossing food if there is 4 fruit taking randomly//
    Fruit2()
    {
        index2 = std::rand()%4;
        score2 = scores2[index2];
        y2 = getmaxy()-230;
        x2 = getmaxx();
        w2 = h2 = 50;
    }

    void draw2()
    {
        readimagefile(names2[index2], x2, y2, x2+80, y2+80);
    }
//6 ghor por por nichhe nambe fruit//
    void update2()
    {
        x2 -= 50;
    }
};


struct Bucket2{
    int x2, y2, w2, h2, steps2, inJump2, rT2;
    Bucket2()
    {
        w2 = 70;
        h2 = 100;
        x2 = (getmaxx() / 2)-200;
        y2 = getmaxy()-250;
        //per press a koto distance//
        steps2 = 20;
        inJump2 = rT2 = 0;
    }

    void draw2()
    {
        readimagefile("img/pic.jpg", x2, y2, x2+w2, y2+h2);
    }

    void input2()
    {
        if(!kbhit()) return;

        char key2 = getch();
       /* if(key2 == 'a'||key2 ==37)
        {
            x2 -= steps2;
            x2 += 2 * getmaxx();
            x2 %= getmaxx();
        }
        if(key2 == 'd'|| key2== 39)
        {
            x2 += steps2;
            x2 %= getmaxx();
        }*/
        //jump button use//
        if(key2 == 'w'||key2 == 72 || key2==75)
        {
            if(inJump2 == 1) return;
            inJump2 = 1;
            rT2 = 300;
            y2 -= max_jump2;
        }
    }
//reamaing time(rt) jokhn 0 and injump 1 then namte hbe//
    void update2(int d2)
    {
        rT2 -= d2;
        if(rT2 <= 0 && inJump2)
        {
            inJump2 = 0;
            y2 += max_jump2;
            rT2 = 0;
        }
    }
};

void highscore2(int score2)
{
    //compare the score with high score
    ifstream myFile("score.txt");
    int hs2;
    myFile >> hs2;
    if(score2>hs2){
        ofstream highScore2("score.txt");
        //iscore=score;
        highScore2 << score2;
        outtextxy(200,200,"HIGH SCORE !!!");
        highScore2.close();
    }
}


void level2(void)
{

//readimagefile("img//magamind.jpg", 0, 500, 800, 800);
    Bucket2 b2;
    vector<Fruit2> fruits2;
    int time_lapse2 = 0, total2 = 0, miss2= 0, flag2 = 1,lifeline2=3;
    Fruit2 fi2;
    int jscore2=0;

    while(miss2<3 )
    {
       // int jscore=0;
        cleardevice();
        readimagefile("img//moon.jpg", 0,0, 800, 300);
        readimagefile("img//g2.jpg", 0,450, 800, 700);
       // setfillstyle(SOLID_FILL,BLACK);

        //screen corner a cuurent score//
      //  char temp[100];
        //outtextxy(80,10, temp);
        char temp2[100],t2[10];
        itoa(jscore2, temp2, 10);
        outtextxy(270,20, temp2);


        b2.input2();
        //b.update(100);
        b2.update2(100);
        b2.draw2();
        for(int i = 0; i < fruits2.size(); ++i)
        {
            fruits2[i].draw2();
            fruits2[i].update2();
        }
        time_lapse2 += 100;
        if(time_lapse2 >= 700)
        {
            fruits2.push_back(Fruit2());
            time_lapse2 = 0;
        }

        for(int i = fruits2.size()-1; i >= 0; --i)
        {
            if(fruits2[i].x2 >= b2.x2 && (fruits2[i].x2+fruits2[i].w2) <= (b2.x2+b2.w2))
            {
                if(fruits2[i].y2 >= b2.y2 && (fruits2[i].y2+fruits2[i].h2) <= (b2.y2 + b2.h2))
                {
                    //jump er jnno score count//
                   miss2++;
                   lifeline2=lifeline2-miss2;
                   sndPlaySound("sounds//no.wav", SND_FILENAME | SND_ASYNC );
                  // if(miss>3)
                  // {*/
                       cleardevice();

                      // cleardevice();
                      // setcolor(10);
                      // settextstyle(6,0,6);
                      // outtextxy(250,250,"Lifeline ");



                  /* }
                    //fruits.erase(fruits.begin() + i);*/

                   break;
                   exit(0);
                }
                else
            {
                jscore2=jscore2+5;
                sndPlaySound("sounds//beep.wav", SND_FILENAME | SND_ASYNC );
            }


            }
            else
           {
               setcolor(10);
               settextstyle(6,0,6);
               outtextxy(20,20,"score = ");
               itoa(jscore2, temp2, 10);
               outtextxy(270,20, temp2);
               setcolor(10);
               settextstyle(3,0,2);
               outtextxy(520,20,"Lifeline = ");
               itoa(lifeline2, t2, 10);
               outtextxy(600,20, t2);
            }

        }


       for(int i = fruits2.size()-1; i >= 0; --i)
        {

            if(fruits2[i].y2 >= getmaxy()+10)
            {
               // if(fruits[i].score < 0) miss++;
               // if(miss >= MAX_SCORE)
                //{
                   // flag = 0;
                   // readimagefile("img/byebye.jpg", 0, 0, getmaxx(), getmaxy());
                   // sndPlaySound("sounds//minions-tadaa.wav", SND_FILENAME | SND_ASYNC );
                    //delay(200);
                    //store_high_scorecoc11(total);
                    getch();
                    break;
               // }
                fruits2.erase(fruits2.begin() + i);
            }
  delay(50);
}
//highscore(jscore);

    }
    if(miss2==3)
        {
            readimagefile("img/gameover.jpg", 0, 0, 800, 700);
          //  settextstyle(6,0,6)
            outtextxy(250,250,"Game Over");
            highscore2(jscore2);
               getch();
        }
      }

