#include<graphics.h>
#include <iostream>
using namespace std;

void exit(void)
{

    cleardevice();
    readimagefile("img//exit2.jpg",0,0,800,600);
    settextstyle(0,0,3);
    setcolor(2);
    outtextxy(230,340,"THANKS for stoping by :)");
    outtextxy(200,390,"Press any key to exit");
    getch();

}


