#include <graphics.h>
#include <iostream>

void level1(void);
void level2(void);
void level3(void);
void menu(void);

void newgame(void)
{
    char key;
    setfillstyle(SOLID_FILL,BLACK);
    int x = 45;
    int y=70, t=110;

    while(1)
    {

        readimagefile("img/newgame.jpg", 0, 0, getmaxx(), getmaxy());
        readimagefile("img/megamind2.jpg", x, y, x+60, y+60);

        key=getch();

        if(y>70 && (key==72 || key=='w'))
        {
            y=y-t;
            bar(x,y+t,x+50,y+50+t);
            x=x-40;

        }
        else if(y<290 && (key==80 || key=='s'))
        {
            y+=t;
            bar(x,y-t,x+50,y+50-t);
            x=x+40;
        }

        else if(y==70 && key==13)
        {
            level1();
            //game_play();
            setfillstyle(SOLID_FILL, BLACK);
        }
       else if(y==180 && key==13)
        {
            level2();
        }
        else if(y==290 && key==13)
        {
            level3();
        }
         else if(key==27)
            menu();


   /* else if(y==360 && key==13)
        {
            credit();
        }
        else if(y==450 && key==13)
        {
            exit();
            break;
        }*/

    }
}
