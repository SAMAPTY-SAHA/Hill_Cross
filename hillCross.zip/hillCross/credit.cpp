
#include<graphics.h>
#include <iostream>
using namespace std;

void credit(void)
{

    cleardevice();
    readimagefile("img//credits.jpg",0,0,800,500);
    int z = 0,i=-50,speed=3;
    while(!kbhit())
    {
        setfillstyle(SOLID_FILL,BLACK);

        readimagefile("img/jarin.jpg", i, 510, i+60, 560);

        readimagefile("img/puja.jpg", 740-i, 510, 800-i, 560);
        if(i>=800)
        {
            i=-60;
        }
        else{
            bar(i-speed, 510, i, 561);
            bar(740-i+60, 510, 800-i+speed+1, 561);
            i=i+speed;
            }

        delay(10);
        if(z>100)
            z=0;
    }
    cleardevice();
    setbkcolor(0);
    getch();
}
