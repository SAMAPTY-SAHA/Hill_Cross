
#include <iostream>
#include <fstream>
#include <string>
#include <graphics.h>
#include <bits/stdc++.h>
using namespace std;

const int MAX_SCORE3 = 4, max_jump3 = 70,s3=0;
char names3[][1000] = {"img/a.jpg", "img/e.jpg", "img/c.jpg", "img/d.jpg"};
int scores3[] = {3, 5, -5, -2};
struct Fruit3{
    int x3, y3, w3, h3;
    int score3;
    int index3;
    //for chossing food if there is 4 fruit taking randomly//
    Fruit3()
    {
        index3 = std::rand()%4;
        score3 = scores3[index3];
        y3 = getmaxy()-200;
        x3 = getmaxx();
        w3 = h3 = 50;
    }

    void draw3()
    {
        readimagefile(names3[index3], x3, y3, x3+50, y3+50);
    }
//6 ghor por por nichhe nambe fruit//
    void update3()
    {
        x3 -= 50;
    }
};


struct Bucket3{
    int x3, y3, w3, h3, steps3, inJump3, rT3;
    Bucket3()
    {
        w3 = 60;
        h3 = 90;
        x3 = (getmaxx() / 2)-200;
        y3 = getmaxy()-240;
        //per press a koto distance//
        steps3 = 20;
        inJump3 = rT3 = 0;
    }

    void draw3()
    {
        readimagefile("img/pic.jpg", x3, y3, x3+w3, y3+h3);
    }

    void input3()
    {
        if(!kbhit()) return;

        char key3 = getch();
        /*if(key3 == 'a'||key3 ==37)
        {
            x3 -= steps3;
            x3 += 2 * getmaxx();
            x3 %= getmaxx();
        }
        if(key3 == 'd'|| key3== 39)
        {
            x3 += steps3;
            x3 %= getmaxx();
        }*/
        //jump button use//
        if(key3 == 'w'||key3 == 72 || key3==75)
        {
            if(inJump3 == 1) return;
            inJump3 = 1;
            rT3 = 300;
            y3 -= max_jump3;
        }
    }
//reamaing time(rt) jokhn 0 and injump 1 then namte hbe//
    void update3(int d3)
    {
        rT3 -= d3;
        if(rT3 <= 0 && inJump3)
        {
            inJump3 = 0;
            y3 += max_jump3;
            rT3 = 0;
        }
    }
};

void highscore3(int score3)
{
    //compare the score with high score
    ifstream myFile("score.txt");
    int hs3;
    myFile >> hs3;
    if(score3>hs3){
        ofstream highScore3("score.txt");
        //iscore=score;
        highScore3 << score3;
        outtextxy(200,200,"HIGH SCORE !!!");
        highScore3.close();
    }
}


void level3(void)
{

//readimagefile("img//magamind.jpg", 0, 500, 800, 800);
    Bucket3 b3;
    vector<Fruit3> fruits3;
    int time_lapse3 = 0, total3 = 0, miss3= 0, flag3 = 1,lifeline3=3;
    Fruit3 fi3;
    int jscore3=0;

    while(miss3<3 )
    {
       // int jscore=0;
        cleardevice();
        readimagefile("img//g3.jpg", 0,450, 800, 700);
        readimagefile("img//moon.jpg", 0,0, 800, 300);
       // setfillstyle(SOLID_FILL,BLACK);

        //screen corner a cuurent score//
      //  char temp[100];
        //outtextxy(80,10, temp);
        char temp3[100],t3[10];
        itoa(jscore3, temp3, 10);
        outtextxy(270,20, temp3);


        b3.input3();
        //b.update(100);
        b3.update3(100);
        b3.draw3();
        for(int i = 0; i < fruits3.size(); ++i)
        {
            fruits3[i].draw3();
            fruits3[i].update3();
        }
        time_lapse3 += 130;
        if(time_lapse3 >= 700)
        {
            fruits3.push_back(Fruit3());
            time_lapse3 = 0;
        }

        for(int i = fruits3.size()-1; i >= 0; --i)
        {
            if(fruits3[i].x3 >= b3.x3 && (fruits3[i].x3+fruits3[i].w3) <= (b3.x3+b3.w3))
            {
                if(fruits3[i].y3 >= b3.y3 && (fruits3[i].y3+fruits3[i].h3) <= (b3.y3 + b3.h3))
                {
                    //jump er jnno score count//
                   miss3++;
                   lifeline3=lifeline3-1;
                   sndPlaySound("sounds//no.wav", SND_FILENAME | SND_ASYNC );
                  // if(miss>3)
                  // {*/
                       cleardevice();

                      // cleardevice();
                      // setcolor(10);
                      // settextstyle(6,0,6);
                      // outtextxy(250,250,"Lifeline ");



                  /* }
                    //fruits.erase(fruits.begin() + i);*/

                   break;
                   exit(0);
                }
                else
            {
                jscore3=jscore3+5;
                sndPlaySound("sounds//beep.wav", SND_FILENAME | SND_ASYNC );
            }


            }
            else
           {
               setcolor(10);
               settextstyle(6,0,6);
               outtextxy(20,20,"score = ");
               itoa(jscore3, temp3, 10);
               outtextxy(270,20, temp3);
               setcolor(10);
               settextstyle(3,0,2);
               outtextxy(520,20,"Lifeline = ");
               itoa(lifeline3, t3, 10);
               outtextxy(600,20, t3);
            }

        }


       for(int i = fruits3.size()-1; i >= 0; --i)
        {

            if(fruits3[i].y3 >= getmaxy()+10)
            {
               // if(fruits[i].score < 0) miss++;
               // if(miss >= MAX_SCORE)
                //{
                   // flag = 0;
                   // readimagefile("img/byebye.jpg", 0, 0, getmaxx(), getmaxy());
                   // sndPlaySound("sounds//minions-tadaa.wav", SND_FILENAME | SND_ASYNC );
                    //delay(200);
                    //store_high_scorecoc11(total);
                    getch();
                    break;
               // }
                fruits3.erase(fruits3.begin() + i);
            }
  delay(50);
}
//highscore(jscore);

    }
    if(miss3==3)
        {
            readimagefile("img/gameover.jpg", 0, 0, 800, 700);
          //  settextstyle(6,0,6)
            outtextxy(250,250,"Game Over");
            highscore3(jscore3);
               getch();
        }
      }


