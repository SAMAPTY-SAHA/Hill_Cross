#include <iostream>
#include <fstream>
#include <string>
#include <graphics.h>
#include <bits/stdc++.h>
using namespace std;

const int MAX_SCORE = 4, max_jump = 70,s=0;
char names[][1000] = {"img/a.jpg", "img/b.jpg", "img/c.jpg", "img/d.jpg"};
int scores[] = {3, 5, -5, -2};
struct Fruit{
    int x, y, w, h;
    int score;
    int index;
    //for chossing food if there is 4 fruit taking randomly//
    Fruit()
    {
        index = std::rand()%4;
        score = scores[index];
        y = getmaxy()-200;
        x = getmaxx();
        w = h = 50;
    }

    void draw()
    {
        readimagefile(names[index], x, y, x+50, y+50);
    }
//6 ghor por por nichhe nambe fruit//
    void update()
    {
        x -= 50;
    }
};


struct Bucket{
    int x, y, w, h, steps, inJump, rT;
    Bucket()
    {
        w = 60;
        h = 90;
        x = (getmaxx() / 2)-200;
        y = getmaxy()-240;
        //per press a koto distance//
        steps = 20;
        inJump = rT = 0;
    }

    void draw()
    {
        readimagefile("img/pic.jpg", x, y, x+w, y+h);
    }

    void input()
    {
        if(!kbhit()) return;

        char key = getch();
        /*if(key == 'a'||key ==37)
        {
            x -= steps;
            x += 2 * getmaxx();
            x %= getmaxx();
        }
        if(key == 'd'|| key== 39)
        {
            x += steps;
            x %= getmaxx();
        }*/
        //jump button use//
        if(key == 'w'||key == 72 || key==75)
        {
            if(inJump == 1) return;
            inJump = 1;
            rT = 300;
            y -= max_jump;
        }
    }
//reamaing time(rt) jokhn 0 and injump 1 then namte hbe//
    void update(int d)
    {
        rT -= d;
        if(rT <= 0 && inJump)
        {
            inJump = 0;
            y += max_jump;
            rT = 0;
        }
    }
};

void highscore(int score)
{
    //compare the score with high score
    ifstream myFile("score.txt");
    int hs;
    myFile >> hs;
    if(score>hs){
        ofstream highScore("score.txt");
        //iscore=score;
        highScore << score;
        outtextxy(200,200,"HIGH SCORE !!!");
        highScore.close();
    }
}


void level1(void)
{

//readimagefile("img//magamind.jpg", 0, 500, 800, 800);
    Bucket b;
    vector<Fruit> fruits;
    int time_lapse = 0, total = 0, miss= 0, flag = 1,lifeline=3;
    Fruit fi;
    int jscore=0;

    while(miss<3 )
    {
       // int jscore=0;
        cleardevice();
        readimagefile("img//moon.jpg", 0,0, 800, 300);
        readimagefile("img//g1.jpg", 0,450, 800, 700);
       // setfillstyle(SOLID_FILL,BLACK);

        //screen corner a cuurent score//
      //  char temp[100];
        //outtextxy(80,10, temp);
        char temp[100],t[10];
        itoa(jscore, temp, 10);
        outtextxy(270,20, temp);


        b.input();
        //b.update(100);
        b.update(100);
       b.draw();
        for(int i = 0; i < fruits.size(); ++i)
        {
            fruits[i].draw();
            fruits[i].update();
        }
        time_lapse += 50;
        if(time_lapse >= 700)
        {
            fruits.push_back(Fruit());
            time_lapse = 0;
        }

        for(int i = fruits.size()-1; i >= 0; --i)
        {
            if(fruits[i].x >= b.x && (fruits[i].x+fruits[i].w) <= (b.x+b.w))
            {
                if(fruits[i].y >= b.y && (fruits[i].y+fruits[i].h) <= (b.y + b.h))
                {
                    //jump er jnno score count//
                   miss++;
                   lifeline=lifeline-1;
                   sndPlaySound("sounds//no.wav", SND_FILENAME | SND_ASYNC );
                  // if(miss>3)
                  // {*/
                       cleardevice();

                      // cleardevice();
                      // setcolor(10);
                      // settextstyle(6,0,6);
                      // outtextxy(250,250,"Lifeline ");



                  /* }
                    //fruits.erase(fruits.begin() + i);*/

                   break;
                   exit(0);
                }
                else
            {
                jscore=jscore+5;
                sndPlaySound("sounds//beep.wav", SND_FILENAME | SND_ASYNC );
            }


            }
            else
           {
               setcolor(10);
               settextstyle(6,0,6);
               outtextxy(20,20,"score = ");
               itoa(jscore, temp, 10);
               outtextxy(270,20, temp);
               setcolor(10);
               settextstyle(3,0,2);
               outtextxy(520,20,"Lifeline = ");
               itoa(lifeline, t, 10);
               outtextxy(600,20, t);
            }

        }


      /* for(int i = fruits.size()-1; i >= 0; --i)
        {

            if(fruits[i].y >= getmaxy()+10)
            {
               // if(fruits[i].score < 0) miss++;
               // if(miss >= MAX_SCORE)
                //{
                   // flag = 0;
                   // readimagefile("img/byebye.jpg", 0, 0, getmaxx(), getmaxy());
                   // sndPlaySound("sounds//minions-tadaa.wav", SND_FILENAME | SND_ASYNC );
                    //delay(200);
                    //store_high_scorecoc11(total);
                    getch();
                    break;
               // }
                fruits.erase(fruits.begin() + i);
            }
  delay(200);
}*/
//highscore(jscore);
delay(200);

    }
    if(miss==3)
        {
            readimagefile("img/gameover.jpg", 0, 0, 800, 700);
           // settextstyle(6,0,6)
            outtextxy(250,250,"Game Over");
            highscore(jscore);
               getch();
        }
      }

