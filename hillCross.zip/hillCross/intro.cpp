#include<graphics.h>
#include <iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
void intro(void)
{

    sndPlaySound("sounds//Ollo.wav", SND_FILENAME | SND_ASYNC );
    readimagefile("img/ollo.jpg", 0, 0, getmaxx(), getmaxy());
    getch();
    char name[160];
    int i;
    sndPlaySound("sounds//megamind.wav", SND_FILENAME | SND_ASYNC );
    for(i=1;i<=86;i=i+1)
    {
      sprintf(name,"img//capture//Capture (%d).JPG",i);
      readimagefile(name,0,0,800,600);
      delay(100);

    }
    delay(1000);
    settextstyle(1,0,4);
    outtextxy(100,270,"press any key please");
    getch();
    //setcolor(BLACK);
    cleardevice();

}


