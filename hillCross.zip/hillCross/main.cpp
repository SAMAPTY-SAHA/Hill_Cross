#include<graphics.h>
#include<conio.h>
#include<windows.h>
#include<MMsystem.h>
#include<cstdio>
#include<iostream>
#include<stdlib.h>
using namespace std;

void intro(void);
int menu(void);

int main()
{
    initwindow(800, 600, "Hill Cross (made by Jarin and Puja)",50, 50, false, false);
    intro();
    menu();
    return 0;
}


